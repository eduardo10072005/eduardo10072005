function showLogin() {
    document.getElementById('login-container').style.display = 'block';
    document.getElementById('register-container').style.display = 'none';
}

function showRegister() {
    document.getElementById('login-container').style.display = 'none';
    document.getElementById('register-container').style.display = 'block';
}

function login(event) {
    event.preventDefault();
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;
    const storedEmail = localStorage.getItem('email');
    const storedPassword = localStorage.getItem('password');

    if (email === storedEmail && password === storedPassword) {
        window.location.href = 'servicos.html';
    } else {
        alert('Email ou senha incorretos');
    }
}

function register(event) {
    event.preventDefault();
    const email = document.getElementById('registerEmail').value;
    const password = document.getElementById('registerPassword').value;

    localStorage.setItem('email', email);
    localStorage.setItem('password', password);

    alert('Conta criada com sucesso!');
    showLogin();
}

function bookService(serviceName, date) {
    if (!date) {
        alert('Por favor, selecione uma data');
        return;
    }
    alert(`Serviço de ${serviceName} marcado para ${date}`);
}